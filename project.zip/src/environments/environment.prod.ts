export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyBbUsyhkYiYVxgTpiNgFwmPVYYbVWl0Rwo",
    authDomain: "oshop-9d342.firebaseapp.com",
    databaseURL: "https://oshop-9d342.firebaseio.com",
    projectId: "oshop-9d342",
    storageBucket: "oshop-9d342.appspot.com",
    messagingSenderId: "562777372767"
  }
};
